===========
MP_CJMG1
===========
Created by Funk

This map was auto-generated using the CoDJumper Map Generator on 2025-09-23

INSTALLATION INSTRUCTIONS:

Extract the "mp_cjmg1" folder to your CoD4 directory's "usermaps" folder. In case the usermaps folder doesn't exist, create one.
Make sure the extracted folder includes the following files: 

 - mp_cjmg1.ff
 - mp_cjmg1.iwd
 - mp_cjmg1_load.ff

PLAYING THE MAP:

In the game load your preferred CoDJumper mod and then type into the console:

/devmap mp_cjmg1